import java.util.Scanner;
public class ClassTutorial {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Insert your birth year: ");
        int year = input.nextInt();
        switch (year % 12) {
            case 0:
                System.out.println("Monkey");
        }
    }
}
