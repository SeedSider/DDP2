public class Soal3 {
    public static void main(String[] args) {
        int z = (int) 2.1; //Tidak terjadi error. Namun angka mengalami floor menjadi format integer (menjadi 2)
        System.out.println(z);
    }
}
