/**
 * 
 * @nama: [Usman Sidiq]
 * @npm: [1706039950]
 *
 */
public class Soal4Lab1 {
	/*
	 * Program ini mencetak beberapa kalimat... lagi...
	 * Sebenarnya program ini tidak ada error. Namun apakah program ini jalan?
	 */
	public static void main(String[] args) {
		System.out.println("Kuy ngoding");
		System.out.println("PS: Eresh best grill");
		System.out.println("PS2: Nerofes + Dobel regen kill me plz");
		
		/**
		 * Java merupakan bahasa pemrograman yang case sensitive.
		 * Jadi, ketika fungsi mainnya tidak sesuai dengan format yang benar, maka programnya akan error.
		 */
		
		/**
		 * Mengubah fungsi main menjadi huruf kecil semua
		 */

		/**
		* PS: Eresh best grill indeed :)
		* PS2 : Belom nyampe Shimosa lawan Raikou sama Shuten?
		*/
	}
}
