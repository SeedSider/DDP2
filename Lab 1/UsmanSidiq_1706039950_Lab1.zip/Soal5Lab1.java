/**
 * 
 * @nama: [Usman Sidiq]
 * @npm: [1706039950]
 *
 */
public class Soal5Lab1 {
	/*
	 * Jadi program ini ceritanya ingin mencetak dua kalimat.
	 * "Kalimat pertama" dan "Kalimat Kedua".
	 */
	public static void main(String[] args) {
		System.out.println("Kalimat pertama");
		System.out.print("Kalimat kedua");
	}
	
	/**
	 * Dalam java, hanya boleh ada satu fungsi main dalam satu class.
	 */
	
	/**
	 * Menghapus satu fungsi main dan mengubah satu print menjadi println
	 */

}
