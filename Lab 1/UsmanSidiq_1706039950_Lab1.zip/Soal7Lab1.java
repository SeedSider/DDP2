/**
 * 
 * @nama: [Usman Sidiq]
 * @npm: [1706039950]
 *
 */
public class Soal7Lab1 {
	/*
	 * Jadi di program ini ada beberapa variable
	 * Rencananya mau mencetak sesuatu menggunakan variable tersebut
	 * Sayangnya program ini tidak bisa jalan karena error
	 */
	public static void main(String[] args) {
		String mikon = "Mikonn~";
		int lima = 5;
		double tujuhKoma = 7.98;
		char b = 'b';
		
		//
		System.out.println("Tamamo says " + mikon);
		System.out.println("7.98 kali 5 sama dengan " + (lima*tujuhKoma));
		System.out.println("Huruf kedua alfabet adalah " + b);
		
		/**
		 * Type masing-masing variable belum diset
		 */
		
		/**
		 * Menambahkan type untuk masing-masing variable.
		 * mikon menjadi String, lima menjadi integer, tujuhKoma menjadi double, dan b menjadi char.
		 * 
		 */
	}
}



		/**
		* PS: Support masih suka pake Tamamo ye?
		*/
