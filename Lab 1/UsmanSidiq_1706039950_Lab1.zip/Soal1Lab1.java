/**
 * 
 * @nama: [Usman Sidiq]
 * @npm: [1706039950]
 *
 */
public class Soal1Lab1 {
	/*
	 * Intinya program ini mencetak beberapa kalimat
	 * Tapi error
	 */
	public static void main(String[] args) {
		System.out.println("Let's Learn About java bois");
		System.out.println("But first");
		System.out.println("Is there something wrong with it?");
		System.out.println("Comment below!");
		
		/**
		 * Penyebab errornya adalah karena tidak ada semicolon(;) di akhir statement
		 */
		
		/**
		 * Saya menambahkan semicolon di setiap akhir statement
		 * Kemudian, agar printnya per baris, saya mengubah print menjadi println (opsional)
		 */
	}
}
