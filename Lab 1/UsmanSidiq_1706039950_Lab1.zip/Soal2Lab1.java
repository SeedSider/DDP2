/**
 * @nama: [Usman Sidiq]
 * @npm: [1706039950]
 */
public class Soal2Lab1 {

    /**
     * Baca hasil print nya baik baik.
     * Karena hasil print nya adalah soalnya ya.
     * Kalau hasil print nya tidak rapi,
     * bisa ditambahkan spasi ataupun new line
     */
public static void main(String[] args) {
    System.out.print("Hm, kode sebelumnya kan rapi tapi sekarang kodenya ngga rapi lagi. ");
    System.out.println("Tapi kok masih bisa jalan ya?");
    System.out.println("Jelasin alasannya kenapa kodenya bisa jalan di comment dibawah ya :)");
    System.out.print("Jangan lupa dirapikan serta tulis apa yang kalian rubah apa aja?");

        /**
         * Karena, java tidak memperdulikan apakah codingannya rapi atau tidak dan tidak memperdulikan whitespace.
         * Java hanya memperdulikan apakah codingan yang dibuat sesuai dengan standar penulisan java atau tidak.
         */

        /**
         * Saya mengubah format penulisan beberapa baris dan menghapus tanda tambah (+) yang tidak diperlukan.
         * Saya juga mengubah satu print menjadi println.
         */
    }
}
