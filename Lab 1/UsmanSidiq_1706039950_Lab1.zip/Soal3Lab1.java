/**
 * 
 * @nama: [Usman Sidiq]
 * @npm: [1706039950]
 *
 */
public class Soal3Lab1 {
	/*
	 * Program ini mencetak hello world di konsol...
	 * ... udah basi ya? Maafkeun asdos yang mageran ini!
	 * Programnya error btw
	 */
	public static void main(String[] args) {
		System.out.println("Hello World!");
		
		// ayo tebak ini bahasa apa?
		System.out.println("Ciao mondo!");
		System.out.println("Halo dunia!");
		
		/**
		 * Nama class nya tidak sesuai dengan nama file nya
		 */
		
		/**
		 * Mengubah nama class menjadi Soal3Lab1 sesuai dengan nama file
		 */
	}

}
