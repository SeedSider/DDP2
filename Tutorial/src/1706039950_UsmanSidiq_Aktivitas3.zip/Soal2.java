public class Soal2 {
    public static void main(String[] args) {
        double y = 2; //Tidak terjadi error, namun angka menjadi format double dengan angka di belakang koma
        System.out.println(y);
    }
}
